exports = function(block){
 // Compare the hash.
  hash = utils.crypto.hmac(block.previousHash + block.timestamp + EJSON.stringify(block.data) + block.nonce.toString(), block.index.toString(), "sha256", "base64");
  if (hash == block.hash)
  {
    return true;
  }
  else
  {
    return false;
  }
};