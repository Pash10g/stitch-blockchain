exports = function(fieldsPublished,purpose,expiration_date){
  var http = context.services.get("getGeoFromIP");
  
  var currentIp = EJSON.stringify(context.request.remoteIPAddress).replace(/\"/g,'');
  const url = "http://api.ipstack.com/" + currentIp +  "?access_key=38e4e19eece3bf4e06be3c2e5b5b4edf&format=1";
  var mongodb = context.services.get("mongodb-atlas");
  var profile = mongodb.db("transactions").collection("profiles");
  var logins = mongodb.db("transactions").collection("logins_4_chain");
    console.log("profile gotten " );
    
  return http.get({ url }).then(resp => {
    var doc = {};
    var login_doc = {};
    var blockchain_data = {};
    blockchain_data.ipInformation = EJSON.parse(resp.body.text());
    blockchain_data.location = blockchain_data.ipInformation.location;
    blockchain_data.consumed = false;
    blockchain_data.loginTime = new Date();
    login_doc.user_id = context.user.id;
    login_doc.blockchain_data = blockchain_data;
    
    
    doc.identity_verification_log = {};
    
    doc.identity_verification_log.transaction_details = { "assets_shared" : fieldsPublished, "purpose" : purpose, "expiration_date" : expiration_date };
    doc.user_id = context.user.id;
    doc.owner_id = context.user.id;
    doc.user_data = context.user.data;
    doc.DOB = "1967-03-18T20:35:09";
    doc.last_modified = new Date();
    doc.credit_score = 972;
    doc.assets_range = "$30000 - $50000";
    doc.accounts = { "checking" : {"checking_id" : 180663733231 , "balance" : 77643, date_open: "2017-03-18T20:35:09"  }, 
      "savings" : {"saving_id" : 180663762231 , "balance" : 32221, date_open: "2017-03-18T20:38:09"  },
       "credit_card" : {"card_num" : "5464-3232-2223-4413" , "outstanding_balance" : 22077, date_open: "2017-03-18T20:42:09"  }
    };
    try
    {
      var login_id = logins.insertOne(login_doc);
      doc.identity_verification_log.last_operation_id = login_id.insertedId;
      doc.identity_verification_log.blocks_ids = [];
      console.log(JSON.stringify(doc.user_data));
      var x = profile.updateOne({"user_id" : context.user.id.toString()},{"$set" : doc},
      {upsert : true});
      console.log(JSON.stringify(x));
      
    }
    catch(e)
    {
      console.error("Error " + e.message);
    }
  });
};