exports = function(block){
  // Get collections 
  var nodes = context.services.get("mongodb-atlas").db("assets").collection("nodes");
  var pending_blocks = context.services.get("mongodb-atlas").db("transactions").collection("pending_blocks");
  
  // Retrieve the current block
  var doc = pending_blocks.findOne({index : block.index});
  if (doc)
  {
    // Retrieve approvals vs active nodes
    currentApprovals = doc.approvals;
    
    var numberOfActiveNodes = nodes.count( {"active" : true});
    var approvedNodes = nodes.count({"owner_id" : {"$in" : currentApprovals}});
    
    // See if majority has approved
    if (approvedNodes > (numberOfActiveNodes / 2))
    {
      return true;
    }
    else
    {
      return false;
    }
    
  }
  return false;
};