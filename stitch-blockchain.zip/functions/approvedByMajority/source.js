exports = function(block){
  /*
    Accessing application's values:
    var x = context.values.get("value_name");

    Accessing a mongodb service:
    var collection = context.services.get("mongodb-atlas").db("dbname").collection("coll_name");
    var doc = collection.findOne({owner_id: context.user.id});

    To call other named functions:
    var result = context.functions.execute("function_name", arg1, arg2);

    Try running this in the console below:
    exports('hello world!')

  */
  var pending_blocks = context.services.get("mongodb-atlas").db("transactions").collection("pending_blocks");
  var nodes = context.services.get("mongodb-atlas").db("assets").collection("nodes");
  
  docs = pending_blocks.find({index : block.index});
  
  while (docs.hasNext())
  {
    doc = docs.next();
    currentApprovals = doc.approvals;
    
    numberOfActiveNodes = nodes.count();
    approvedNodes = nodes.count({"owner_id" : {"$in" : currentApprovals}});
    
    if (approvedNodes > (numberOfActiveNodes / 2))
    {
      return true;
    }
    else
    {
      return false;
    }
    
  }
  return false;
};