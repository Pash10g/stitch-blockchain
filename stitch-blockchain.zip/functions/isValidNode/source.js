exports = function(node_id){
  
    var nodes = context.services.get("mongodb-atlas").db("assets").collection("nodes");
  
  
    var approvedNodes = nodes.count({"producer_id" : node_id});
    if (approvedNodes > 0)
    {
      return true;
    }
    else
    {
      return false
    }
};